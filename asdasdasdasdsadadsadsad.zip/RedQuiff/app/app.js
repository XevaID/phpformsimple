async function checkAuthuser() {
  const responseAuth = await fetch(
    "/kode/RedQuiff/api/authusers/checkAuth.php",
  );
  const dataAuth = await responseAuth.json();
  if (dataAuth.status === "success") {
    return;
  } else {
    window.location.href = "/kode/RedQuiff/pages/userin.php";
    // const currentURL = await fetch("/kode/RedQuiff/pages/userin.php");
    // const dataURL = await currentURL.text();
    // document.open();
    // document.write(dataURL);
    // document.close();
    // history.pushState({}, null, "/kode/RedQuiff/pages/userin.php");
  }
}

checkAuthuser();
